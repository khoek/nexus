[OGDF](../../README.md) » [Release Notes](../relnotes.md) » Jacaranda

# OGDF Jacaranda (2007.09)

Released 2007-09-19, hot-fix (2007.09a) released 2007-10-08.

This is the first public release of OGDF.

Changes in Hotfix:
 * Bug fix in `LPSolver_coin.cpp`: Wrong LP passed to Coin
 * Bug fix in `coin.cpp`: Pragma `#warning` not compatible with Visual C++
