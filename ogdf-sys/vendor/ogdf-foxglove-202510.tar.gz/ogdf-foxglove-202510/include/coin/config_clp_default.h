
/***************************************************************************/
/*           HERE DEFINE THE PROJECT SPECIFIC PUBLIC MACROS                */
/*    These are only in effect in a setting that doesn't use configure     */
/***************************************************************************/

/* Version number of project */
#define CLP_VERSION       "1.14"

/* Major Version number of project */
#define CLP_VERSION_MAJOR      1

/* Minor Version number of project */
#define CLP_VERSION_MINOR     14

/* Release Version number of project */
#define CLP_VERSION_RELEASE 9999
