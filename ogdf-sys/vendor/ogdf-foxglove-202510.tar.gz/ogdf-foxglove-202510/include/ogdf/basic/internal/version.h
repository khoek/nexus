#pragma once

#define OGDF_VERSION "2025.10"
